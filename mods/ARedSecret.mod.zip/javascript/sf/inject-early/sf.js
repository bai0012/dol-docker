simpleFrameworks.addto("ModSkillsBox", "ars-skill-Languages")
simpleFrameworks.addto("ModSkillsBox", "ars-skill-InvisibleArts")